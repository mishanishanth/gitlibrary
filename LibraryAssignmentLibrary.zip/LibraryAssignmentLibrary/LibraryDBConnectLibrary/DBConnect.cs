﻿using System;
using System.Data.SqlClient;
namespace LibraryDBConnectLibrary
{
    public class DBConnect
    {
       public  string connectionstring;
        SqlConnection dbcon;
        public void connect(string username,string password)
        {
            connectionstring= @"Data Source=LAPTOP-UDQPO2MH; Initial Catalog=libdb; User ID="+username+"; Password="+password;
            dbcon= new SqlConnection(connectionstring);
            dbcon.Open();
            Console.WriteLine("the connection is established");
            dbcon.Close();
        }

        public void inserdata()
        { 
        
        
        }
        public void updatedata()
        { }
        public void viewdata()
        { }
        
    }
}
