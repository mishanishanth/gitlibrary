﻿using System;
using LibraryDBConnectLibrary;
using LbAssgLibrary;
using System.Collections.Generic;
using System.Linq;


namespace LibraryConsole
{
    internal class Program
    {
        static void Main(string[] args)
        {
            DBConnect dbc=new DBConnect();
            DTOUser dtouser=new DTOUser();
            DTORole dtorole=new DTORole();
            List<DTORole> roles = new List<DTORole>();
            List<DTOUser> users = new List<DTOUser>();

            dtorole.AddRole(roles, "Default");
            while (true)
            {
                //Console.Clear();
                Console.WriteLine("Welcome to County Library System");
                Console.WriteLine("   Roles Management <Press R>");
                Console.WriteLine("   User Management  <Press U>");
                string option = Console.ReadLine();

                if (option.ToUpper() == "R")
                {
                    dtorole.AddRole(roles,"UserInput");
                
                }

                else if(option.ToUpper() == "U")
                {
                    Console.WriteLine("Register for new user <Press R>");
                    Console.WriteLine("Authenticate for Existing User <Press A>");
                    Console.WriteLine("Print User <Press PU>");
                    Console.WriteLine("Print Profile <Press PP>");
                    Console.WriteLine("Login User <Press L>");
                    string input_user=Console.ReadLine();
                    if (input_user.ToUpper() == "R")
                    {
                        while (true)
                        {
                            users.AddRange(dtouser.register(roles));
                            Console.WriteLine("Do you want to add another user(Yes/No)");
                            if (Console.ReadLine().ToUpper() != "YES")
                            {
                                Console.Clear();
                                Console.WriteLine("List of Available users :");
                                foreach (var j in users)
                                    Console.WriteLine(j.username);
                                break;
                            }
                        }
                    }
                    // Begin If for input_user="L" for User Login
                    else if (input_user.ToUpper() == "A")
                    {
                        Console.Clear();

                        Console.WriteLine("Enter your Username");
                        string usrname = Console.ReadLine();
                        Console.WriteLine("Enter your Password");
                        string psswd = Console.ReadLine();
                        if (dtouser.authenticate(users, usrname, psswd))
                        {
                            Console.WriteLine("Login Successful  " +usrname);
                        }
                        else
                        {
                            Console.WriteLine("Login Failed");
                        }
                     
                    }
                    // End If for input_user="L" for User Login

                    else if (input_user.ToUpper() == "PU")
                    {
                        Console.Clear();
                        dtouser.PrintUser(users, "PU");

                    }
                    else if (input_user.ToUpper() == "PP")
                    {
                        Console.Clear();
                        dtouser.PrintUser(users, "PP");
                    }
                    else if (input_user.ToUpper() =="L")
                    {
                        Console.WriteLine("Enter your Username");
                        string usrname = Console.ReadLine();
                        Console.WriteLine("Enter your Password");
                        string psswd = Console.ReadLine();
                        if (dtouser.authenticate(users, usrname, psswd))
                        {
                            Console.WriteLine("User Modification <Press UM>");
                            Console.WriteLine("Logout <Press O>");
                            string louser_input = Console.ReadLine();
                            if (louser_input.ToUpper() == "UM")
                            {
                                dtouser.update_userlist(users, usrname);
                            }
                            else if (louser_input.ToUpper() == "O")
                            {
                                dtouser.logout(users, usrname);
                                Console.WriteLine("User Logged out :" + usrname);
                            }
                        }
                        else 
                        { 
                            Console.WriteLine("Invalid Login"); 
                        }

                    }


                }
            }
        }
    }
}
